package main

import (
	"github.com/aws/aws-lambda-go/lambda"
)

func main () {
	lambda.Start(show)
}

func show() (*book, error) {
    bk := &book{
        ISBN:   "978-1420931693",
        Title:  "The Republic",
        Author: "Plato",
    }

    return bk, nil
}

type book struct {
    ISBN   string `json:"isbn"`
    Title  string `json:"title"`
    Author string `json:"author"`
}